# Playlist backups

## broken

- From: Carol (spotify)

## Road Trip

- From: Alice @ Home (subsonic)
- 2 songs
- Last backed up: 2023-11-15 00:13

For the drive.

1. Song One — Artist A, Guest
2. Instrumental
