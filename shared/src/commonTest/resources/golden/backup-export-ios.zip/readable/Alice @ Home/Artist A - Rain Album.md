# My Rainy Album
_Rain Album_
Artist A

- Account: Alice @ Home (subsonic)
- Rating: 8 / 10
- Your title: My Rainy Album
- Yoin's title: AI Title

## Review

A long review.
Second line.

_Written 2023-11-14 23:13_

## Songs

### Second Song — Artist B

- Rating: 7.5 / 10
- Notes:
  - 2023-11-14 22:15
    > second

### Song One — Artist A

- Rating: 9 / 10
- Notes:
  - 2023-11-14 22:13 · 1:01
    > first listen
    > rain outside
