# Songs whose album Yoin doesn't know

- Account: Carol (spotify)

## Songs

### Cloud Song — Cloud Artist

- Rating: not rated
- Notes:
  - 2023-11-14 22:13
    > cloud note
